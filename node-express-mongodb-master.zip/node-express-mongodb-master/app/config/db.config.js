module.exports = {
  url: "mongodb://0.0.0.0:27017/app_api_development_server"
};
